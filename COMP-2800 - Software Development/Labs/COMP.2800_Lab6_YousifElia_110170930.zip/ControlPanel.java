import javax.swing.*;

public class ControlPanel extends JPanel {

    public ControlPanel(GamePanel gamePanel) {

        JLabel label = new JLabel("Choose Customization:");

        String[] options = {
                "None",
                "Armor 1",
                "Armor 2",
                "Armor 3",
                "Armor 4",
                "Armor 5"
        };

        JComboBox<String> comboBox = new JComboBox<>(options);

        comboBox.addActionListener(e -> {
            int selectedIndex = comboBox.getSelectedIndex();
            gamePanel.setCustomization(selectedIndex);
        });

        add(label);
        add(comboBox);
    }
}