import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.swing.*;

public class GamePanel extends JPanel {

    private BufferedImage playerSheet;
    private BufferedImage armorSheet;

    private BufferedImage playerFrame;
    private BufferedImage armorFrame;

    private int x = 300;
    private int y = 200;

    private Set<Integer> pressedKeys = new HashSet<>();

    public GamePanel() {

        try {
            // Load sprite sheets
            playerSheet = ImageIO.read(new File("player.png"));
            armorSheet = ImageIO.read(new File("armors.png"));

            // Default player frame (top-left 60x60)
            playerFrame = playerSheet.getSubimage(0, 0, 60, 60);

        } catch (IOException e) {
            e.printStackTrace();
        }

        setFocusable(true);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pressedKeys.add(e.getKeyCode());
            }

            @Override
            public void keyReleased(KeyEvent e) {
                pressedKeys.remove(e.getKeyCode());
            }
        });

        // Game loop
        Timer timer = new Timer(60, e -> update());
        timer.start();
    }

    private void update() {

        int speed = 5;

        if (pressedKeys.contains(KeyEvent.VK_W)) y -= speed;
        if (pressedKeys.contains(KeyEvent.VK_S)) y += speed;
        if (pressedKeys.contains(KeyEvent.VK_A)) x -= speed;
        if (pressedKeys.contains(KeyEvent.VK_D)) x += speed;

        repaint();
    }

    public void setCustomization(int selection) {

    if (selection == 0) {
        armorFrame = null;
    } else {

        int spriteWidth = 60;
        int spriteHeight = 60;

        int columns = 2; // your sheet has 2 armors per row

        int index = selection - 1;

        int row = index / columns;
        int col = index % columns;

        int spriteX = col * spriteWidth;
        int spriteY = row * spriteHeight;

        armorFrame = armorSheet.getSubimage(spriteX, spriteY, spriteWidth, spriteHeight);
    }

    repaint();
    requestFocusInWindow();
}

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (playerFrame != null) {
            g.drawImage(playerFrame, x, y, 60, 60, null);
        }

        if (armorFrame != null) {
            g.drawImage(armorFrame, x, y, 60, 60, null);
        }
    }
}